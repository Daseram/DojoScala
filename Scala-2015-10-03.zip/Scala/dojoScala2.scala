import Array._

object dojo{
     def main(args: Array[String]) {
        //Arreglo
        var lista=List(1,2,3)

        lista.map( (x:Int) => println(x+4))

        println(suma(2,2))
    }
    val suma=(x:Int,y:Int) => x+y

    }